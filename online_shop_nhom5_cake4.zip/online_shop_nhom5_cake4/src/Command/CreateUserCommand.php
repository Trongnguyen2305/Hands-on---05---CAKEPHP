<?php
declare(strict_types=1);

namespace App\Command;

use Cake\Command\Command;
use Cake\Console\Arguments;
use Cake\Console\ConsoleIo;
use Cake\Console\ConsoleOptionParser;

class CreateUserCommand extends Command
{
    protected function buildOptionParser(
        ConsoleOptionParser $parser
    ): ConsoleOptionParser {
        return $parser
            ->addArgument('username', ['required' => true])
            ->addArgument('role', [
                'required' => true,
                'choices' => ['admin', 'staff'],
            ])
            ->addArgument('name', ['required' => true]);
    }

    public function execute(Arguments $args, ConsoleIo $io): int
    {
        $users = $this->fetchTable('Users');
        $username = strtolower(trim($args->getArgument('username')));

        if ($users->exists(['username' => $username])) {
            $io->err('Tên đăng nhập đã tồn tại.');

            return static::CODE_ERROR;
        }

        $password = bin2hex(random_bytes(12));

        $user = $users->newEntity([
            'username' => $username,
            'name' => trim($args->getArgument('name')),
            'password' => $password,
            'role' => $args->getArgument('role'),
            'active' => true,
        ], [
            'accessibleFields' => [
                'role' => true,
                'active' => true,
            ],
        ]);

        if (!$users->save($user)) {
            $io->err(json_encode(
                $user->getErrors(),
                JSON_UNESCAPED_UNICODE
            ));

            return static::CODE_ERROR;
        }

        $io->out('Tài khoản: ' . $username);
        $io->out('Quyền: ' . $user->role);
        $io->out('Mật khẩu: ' . $password);

        return static::CODE_SUCCESS;
    }
}