<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\Controller\Controller;
use Cake\Event\EventInterface;
use Cake\Http\Exception\ForbiddenException;

class AppController extends Controller
{
    public function initialize(): void
    {
        parent::initialize();

        $this->loadComponent('Flash');
        $this->loadComponent('Authentication.Authentication');
    }

    public function beforeFilter(EventInterface $event)
    {
        parent::beforeFilter($event);

        $this->setResponse(
            $this->getResponse()->withHeader('Cache-Control', 'no-store')
        );

        $controller = $this->request->getParam('controller');
        $action = $this->request->getParam('action');

        $this->set([
            'currentUser' => null,
            'isAdmin' => false,
        ]);

        if ($controller === 'Users' && $action === 'login') {
            $this->Authentication->addUnauthenticatedActions(['login']);
        }

        $identity = $this->request->getAttribute('identity');

        if ($identity === null) {
            return null;
        }

        $currentUser = $this->fetchTable('Users')->find()
            ->select(['id', 'username', 'name', 'role', 'active'])
            ->where([
                'id' => $identity->getIdentifier(),
                'active' => true,
                'role IN' => ['admin', 'staff'],
            ])
            ->first();

        if (!$currentUser) {
            $this->Authentication->logout();

            return $this->redirect([
                'controller' => 'Users',
                'action' => 'login',
            ]);
        }

        $isAdmin = $currentUser->role === 'admin';

        $this->set(compact('currentUser', 'isAdmin'));

        if ($controller === 'Sach') {
            $allowed = $isAdmin
                ? ['index', 'view', 'add', 'edit', 'delete']
                : ['index', 'view'];

            if (!in_array($action, $allowed, true)) {
                throw new ForbiddenException(
                    'Bạn không có quyền thực hiện thao tác này.'
                );
            }
        }

        return null;
    }
}