<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\Http\Response;
use Cake\ORM\Table;

class SachController extends AppController
{
    private Table $sachTable;

    public function initialize(): void
    {
        parent::initialize();

        $this->loadComponent('Flash');
        $this->viewBuilder()->setLayout('sach');
        $this->sachTable = $this->fetchTable('Sach');
    }

    public function index(): void
    {
        $raw = $this->request->getQuery('q', '');

        $q = is_string($raw)
            ? mb_substr(trim($raw), 0, 200)
            : '';

        $query = $this->sachTable->find();

        if ($q !== '') {
            $query->where([
                'OR' => [
                    'Sach.ten_sach LIKE' => '%' . $q . '%',
                    'Sach.tac_gia LIKE' => '%' . $q . '%',
                ],
            ]);
        }

        $sachList = $this->paginate($query, [
            'limit' => 10,
            'maxLimit' => 50,
            'order' => ['Sach.id' => 'DESC'],
            'sortableFields' => [
                'id',
                'ten_sach',
                'gia',
                'so_luong',
            ],
        ]);

        $this->set(compact('sachList', 'q'));
    }

    public function view(string $id): void
    {
        $sach = $this->sachTable->get($id);

        $this->set(compact('sach'));
    }

    public function add(): ?Response
    {
        $sach = $this->sachTable->newEmptyEntity();

        if ($this->request->is('post')) {
            $sach = $this->sachTable->patchEntity(
                $sach,
                $this->request->getData()
            );

            if ($this->sachTable->save($sach)) {
                $this->Flash->success('Thêm sách thành công.');

                return $this->redirect(['action' => 'index']);
            }

            $this->Flash->error(
                'Chưa thể thêm sách. Vui lòng kiểm tra dữ liệu.'
            );
        }

        $this->set(compact('sach'));

        return null;
    }

    public function edit(string $id): ?Response
    {
        $sach = $this->sachTable->get($id);

        if ($this->request->is(['post', 'put', 'patch'])) {
            $sach = $this->sachTable->patchEntity(
                $sach,
                $this->request->getData()
            );

            if ($this->sachTable->save($sach)) {
                $this->Flash->success('Cập nhật sách thành công.');

                return $this->redirect(['action' => 'index']);
            }

            $this->Flash->error(
                'Chưa thể cập nhật. Vui lòng kiểm tra dữ liệu.'
            );
        }

        $this->set(compact('sach'));

        return null;
    }

    public function delete(string $id): Response
    {
        $this->request->allowMethod(['post', 'delete']);

        $sach = $this->sachTable->get($id);

        if ($this->sachTable->delete($sach)) {
            $this->Flash->success('Xóa sách thành công.');
        } else {
            $this->Flash->error('Không thể xóa sách này.');
        }

        return $this->redirect(['action' => 'index']);
    }
}