<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\Http\Response;

class UsersController extends AppController
{
    public function login(): ?Response
    {
        $this->request->allowMethod(['get', 'post']);
        $this->viewBuilder()->setLayout('login');

        $result = $this->Authentication->getResult();

        if ($result && $result->isValid()) {
            if ($this->request->is('post')) {
                $this->request->getSession()->renew();
            }

            return $this->redirect([
                'controller' => 'Sach',
                'action' => 'index',
            ]);
        }

        if ($this->request->is('post')) {
            $this->Flash->error(
                'Tên đăng nhập hoặc mật khẩu không đúng.'
            );
        }

        $raw = $this->request->getData('username', '');
        $this->set('username', is_string($raw) ? $raw : '');

        return null;
    }

    public function logout(): Response
    {
        $this->request->allowMethod(['post']);

        $this->Authentication->logout();
        $this->request->getSession()->destroy();

        return $this->redirect([
            'controller' => 'Users',
            'action' => 'login',
        ]);
    }
}