<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

class Sach extends Entity
{
    protected $_accessible = [
        'ten_sach' => true,
        'tac_gia' => true,
        'gia' => true,
        'so_luong' => true,
        'mo_ta' => true,
        '*' => false,
    ];
}