<?php
declare(strict_types=1);

namespace App\Model\Table;

use ArrayObject;
use Cake\Event\EventInterface;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class SachTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('sach');
        $this->setPrimaryKey('id');
        $this->setDisplayField('ten_sach');
        $this->setEntityClass(\App\Model\Entity\Sach::class);

        $this->addBehavior('Timestamp');
    }

    public function beforeMarshal(
        EventInterface $event,
        ArrayObject $data,
        ArrayObject $options
    ): void {
        foreach (['ten_sach', 'tac_gia', 'mo_ta'] as $field) {
            if (isset($data[$field]) && is_string($data[$field])) {
                $data[$field] = trim($data[$field]);
            }
        }
    }

    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('ten_sach')
            ->maxLength('ten_sach', 200)
            ->requirePresence('ten_sach', 'create')
            ->notEmptyString('ten_sach', 'Vui lòng nhập tên sách.');

        $validator
            ->scalar('tac_gia')
            ->maxLength('tac_gia', 150)
            ->requirePresence('tac_gia', 'create')
            ->notEmptyString('tac_gia', 'Vui lòng nhập tác giả.');

        $validator
            ->requirePresence('gia', 'create')
            ->notEmptyString('gia', 'Vui lòng nhập giá bán.')
            ->decimal('gia', null, 'Giá phải là số hợp lệ.')
            ->greaterThanOrEqual('gia', 0, 'Giá không được âm.')
            ->lessThanOrEqual(
                'gia',
                99999999.99,
                'Giá vượt giới hạn cho phép.'
            )
            ->add('gia', 'dinhDangGia', [
                'rule' => function ($value, array $context): bool {
                    return is_scalar($value)
                        && preg_match(
                            '/^\d+(?:\.\d{1,2})?$/D',
                            (string)$value
                        ) === 1;
                },
                'message' => 'Giá dùng dấu chấm và tối đa 2 số lẻ.',
            ]);

        $validator
            ->requirePresence('so_luong', 'create')
            ->notEmptyString('so_luong', 'Vui lòng nhập số lượng.')
            ->integer('so_luong', 'Số lượng phải là số nguyên.')
            ->greaterThanOrEqual(
                'so_luong',
                0,
                'Số lượng không được âm.'
            )
            ->lessThanOrEqual(
                'so_luong',
                2147483647,
                'Số lượng vượt giới hạn cho phép.'
            );

        $validator
            ->scalar('mo_ta')
            ->maxLength('mo_ta', 5000)
            ->allowEmptyString('mo_ta');

        return $validator;
    }
}