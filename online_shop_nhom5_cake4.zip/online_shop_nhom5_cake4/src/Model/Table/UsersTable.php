<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class UsersTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('users');
        $this->setPrimaryKey('id');
        $this->setDisplayField('username');
        $this->setEntityClass(\App\Model\Entity\User::class);
        $this->addBehavior('Timestamp');
    }

    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('username')
            ->maxLength('username', 50)
            ->requirePresence('username', 'create')
            ->notEmptyString('username')
            ->add('username', 'format', [
                'rule' => ['custom', '/^[a-zA-Z0-9_.-]{3,50}$/D'],
                'message' => 'Tên đăng nhập không hợp lệ.',
            ]);

        $validator
            ->scalar('name')
            ->maxLength('name', 100)
            ->requirePresence('name', 'create')
            ->notEmptyString('name');

        $validator
            ->scalar('password')
            ->minLength('password', 12)
            ->maxLength('password', 72)
            ->requirePresence('password', 'create')
            ->notEmptyString('password');

        $validator
            ->requirePresence('role', 'create')
            ->inList('role', ['admin', 'staff']);

        $validator
            ->requirePresence('active', 'create')
            ->boolean('active');

        return $validator;
    }

    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->isUnique(['username']));

        return $rules;
    }

    public function findActive(Query $query, array $options): Query
    {
        return $query->where([$this->aliasField('active') => true]);
    }
}