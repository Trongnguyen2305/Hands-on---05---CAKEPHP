<?php $this->assign('title', $sach->ten_sach); ?>

<div class="page-head">
    <h1><?= h($sach->ten_sach) ?></h1>

    <?php if ($isAdmin): ?>
    <?= $this->Html->link(
        'Sửa thông tin',
        ['action' => 'edit', $sach->id],
        ['class' => 'button']
    ) ?>
<?php endif; ?>
</div>

<section class="card">
    <dl class="book-detail">
        <div>
            <dt>Mã sách</dt>
            <dd><?= (int)$sach->id ?></dd>
        </div>

        <div>
            <dt>Tác giả</dt>
            <dd><?= h($sach->tac_gia) ?></dd>
        </div>

        <div>
            <dt>Giá bán</dt>
            <dd>
                <?= number_format(
                    (float)$sach->gia,
                    2,
                    ',',
                    '.'
                ) ?> đồng
            </dd>
        </div>

        <div>
            <dt>Số lượng</dt>
            <dd><?= (int)$sach->so_luong ?> quyển</dd>
        </div>

        <div>
            <dt>Ngày tạo</dt>
            <dd>
                <?= h(
                    $sach->created?->format('d/m/Y H:i') ?? '—'
                ) ?>
            </dd>
        </div>

        <div>
            <dt>Cập nhật gần nhất</dt>
            <dd>
                <?= h(
                    $sach->modified?->format('d/m/Y H:i') ?? '—'
                ) ?>
            </dd>
        </div>
    </dl>

    <h2>Mô tả</h2>

    <div class="description">
        <?= nl2br(h($sach->mo_ta ?: 'Chưa có mô tả.')) ?>
    </div>

    <div class="form-actions">
        <?= $this->Html->link(
            'Về danh sách',
            ['action' => 'index'],
            ['class' => 'button secondary']
        ) ?>
    </div>
</section>