<h1>Đăng nhập</h1>

<p class="intro">
    Đăng nhập để truy cập hệ thống quản lý sách.
</p>

<?= $this->Form->create(null) ?>

<?= $this->Form->control('username', [
    'label' => 'Tên đăng nhập',
    'required' => true,
    'maxlength' => 50,
    'autocomplete' => 'username',
    'autocapitalize' => 'none',
    'spellcheck' => 'false',
    'value' => $username,
]) ?>

<?= $this->Form->control('password', [
    'label' => 'Mật khẩu',
    'type' => 'password',
    'required' => true,
    'autocomplete' => 'current-password',
    'value' => '',
]) ?>

<?= $this->Form->button('Đăng nhập') ?>

<?= $this->Form->end() ?>