<!DOCTYPE html>
<html lang="vi">
<head>
    <?= $this->Html->charset() ?>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Đăng nhập | BookSpace</title>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: 24px;
            background: linear-gradient(135deg, #14243b, #3057a5);
            font: 15px/1.6 "Segoe UI", Arial, sans-serif;
            color: #24354f;
        }

        .login-box {
            width: 100%;
            max-width: 420px;
            padding: 36px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 22px 70px #0003;
        }

        .brand {
            margin: 0;
            color: #3766e8;
            font-size: 25px;
            font-weight: 750;
        }

        h1 { font-size: 23px; margin: 20px 0 5px; }

        .intro {
            margin: 0 0 25px;
            color: #64748b;
            font-size: 13px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-size: 13px;
            font-weight: 600;
        }

        .input { margin-bottom: 19px; }

        input:not([type="hidden"]) {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #dce4f0;
            border-radius: 9px;
            font: inherit;
            background: #f8faff;
        }

        input:focus {
            outline: 3px solid #dce7ff;
            border-color: #7398fa;
        }

        button {
            width: 100%;
            padding: 12px;
            border: 0;
            border-radius: 9px;
            background: #3766e8;
            color: white;
            font: 600 14px "Segoe UI", Arial, sans-serif;
            cursor: pointer;
        }

        button:hover { background: #2856d7; }

        button:focus-visible {
            outline: 3px solid #9db9ff;
            outline-offset: 3px;
        }

        .message {
            padding: 11px 13px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-size: 13px;
            background: #fff1f3;
            color: #a63e50;
        }

        .hidden { display: none; }

        .footer {
            margin-top: 25px;
            text-align: center;
            color: #94a3b8;
            font-size: 11px;
        }
    </style>
</head>

<body>
    <main class="login-box">
        <p class="brand">BookSpace</p>

        <?= $this->Flash->render() ?>
        <?= $this->fetch('content') ?>

        <div class="footer">Nhóm 5 · DA23TTD</div>
    </main>
</body>
</html>